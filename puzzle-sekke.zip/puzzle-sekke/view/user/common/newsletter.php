<div class="container-fluid wrapper-margin-top"
     id="newsletter-section">
	<div class="row">
		<div class="col-sm-4 col-md-4 col-lg-4 col-sm-offset-4 col-md-offset-4 col-lg-offset-4">
			<p class="newletter-title"> با اشتراک در خبرنامه از آخرین اخبار مطلع شوید...</p>
			<form class="form-inline">
				<div class="input-group input-group-lg">
					<input type="text" class="form-control" placeholder="ایمیل خود را وارد نمایید...">
					<span class="input-group-btn">
        <button class="btn btn-info" type="button">اشتراک</button>
      </span>
				</div>
			</form>
		</div>
	</div>
</div>
