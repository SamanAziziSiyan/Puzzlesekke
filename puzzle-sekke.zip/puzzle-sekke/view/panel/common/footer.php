<div class="clearfix"></div>
<div class="container-fluid" id="footer">
    <div class="row">
        <div class="col-sm-12">

            <p>کلیه حقوق سایت متعلق به <a href="www.puzzle-sekke.ir">سازنده</a> می باشد.</p>

        </div>
    </div>
</div>
</body>
</html>