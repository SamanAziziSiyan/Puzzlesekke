<?php include "../../init.php";  ?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8" />
    <title>داشبورد </title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

    <link rel="stylesheet" href="../../assets/panel/css/bootstrap.rtl.css" />
    <link rel="stylesheet" href="../../assets/panel/css/style.css" />
    <link href="../../assets/panel/css/persianDatepicker-lightorang.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/panel/css/font-awesome.css" />

    <script src="../../assets/panel/js/jquery.min.1.11.2.js"></script>
    <script src="../../assets/panel/js/bootstrap.js"></script>
    <script src="../../assets/panel/js/sweetalert.min.js"></script>
    <!--    behzadi date picker-->
    <script src="../../assets/panel/js/persianDatepicker.js"></script>
    <script src="../../assets/panel/js/admin-custom.js"></script>
    <script src="../../assets/panel/ckeditor/ckeditor.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>

</head>
<body class="top-body">