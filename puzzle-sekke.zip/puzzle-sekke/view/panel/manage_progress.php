
<!--header-->
<?php include "common/header.php" ?>
<!-- top-nav-->
<?php include "common/top-nav.php" ?>
<!-- right-nav-->
<?php include "common/right-nav.php" ?>
<!--content -->
<?php include "page-content/manage-progressbar-content.php" ?>
<!-- footer -->
<?php include "common/footer.php" ?>