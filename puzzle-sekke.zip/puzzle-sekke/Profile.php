<!--header-->
<?php include "view/user/common/header.php" ?>
<!--slide-nav-->
<?php include "view/user/common/slide-nav.php" ?>
<!--Topbar-->
<?php include "view/user/common/top-bar.php" ?>
<!--Top menu-->
<?php include "view/user/common/top-menu.php" ?>
<!--user-profile -->
<!--login & registration-->
<?php include "view/user/profile/Profile.php" ?>
<!--newsletter section-->
<?php include "view/user/common/newsletter.php" ?>
<!--footer section-->
<?php include "view/user/common/footer.php" ?>
