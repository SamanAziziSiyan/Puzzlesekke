<!--header-->
<?php include "view/user/common/header.php" ?>
<!--slide-nav-->
<?php include "view/user/common/slide-nav.php" ?>
<!--Topbar-->
<?php include "view/user/common/top-bar.php" ?>
<!--Top menu-->
<?php include "view/user/common/top-menu.php" ?>
<!--single header section-->
<?php include "view/user/single/single.php" ?>
<!--newsletter section-->
<?php include "view/user/common/newsletter.php" ?>
<!--footer section-->
<?php include "view/user/common/footer.php" ?>
