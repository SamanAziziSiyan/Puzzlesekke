<?php
//	including all your important php files here instead of include them in every single Page
include "model/dataBase.php";
include "functions/functions.php";
include "model/user.php";
include "model/Coin-calc.php";

