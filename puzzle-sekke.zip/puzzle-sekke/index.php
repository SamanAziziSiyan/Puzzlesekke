
<!--header-->
<?php include "view/user/common/header.php" ?>
<!--boot-side-menu-->
<?php include "view/user/common/slide-nav.php" ?>
<!--Topbar-->
<?php include "view/user/common/top-bar.php" ?>
<!--Top menu-->
<?php include "view/user/common/top-menu.php" ?>
<!--Hero Header-->
<?php include "view/user/index/hero-header.php" ?>
<!--slider-info-ads-->
<?php include "view/user/index/slider-info-ads.php" ?>
<!--newsletter section-->
<?php include "view/user/common/newletter.php" ?>
<!--footer section-->
<?php include "view/user/common/footer.php" ?>