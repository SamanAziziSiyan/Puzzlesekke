<!--header-->
<?php include "view/user/common/header.php";?>
<!--Slide Nav-->
<?php include "view/user/common/slide-nav.php";?>
<!--Top-bar-->
<?php include "view/user/common/top-bar.php";?>
<!--Top menu-->
<?php include "view/user/common/top-menu.php";?>
<!--login & registration-->
<?php include "view/user/Login-register/Login-register.php";?>
<!--newsletter section-->
<?php include "view/user/common/newsletter.php";?>
<!--footer section-->
<?php include "view/user/common/footer.php";?>
